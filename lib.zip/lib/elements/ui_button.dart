import 'package:flutter/material.dart';

var otpRoute = '/otp';
var logRoute = '/';

class LogButton extends StatelessWidget {
  const LogButton({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child:
          _buildButton("Log In", context, 300, 55, Colors.blue[400], otpRoute),
    );
  }
}

class NextButton extends StatelessWidget {
  const NextButton({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: _buildButton("Next", context, 100, 55, Colors.blue[400], logRoute),
    );
  }
}

class Backbutton extends StatelessWidget {
  const Backbutton({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: _buildButton("Back", context, 100, 55, Colors.black12, logRoute),
    );
  }
}

class SendButton extends StatelessWidget {
  const SendButton({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: _buildButton("Send", context, 100, 55, Colors.blue[400], logRoute),
    );
  }
}

Widget _buildButton(String text, BuildContext context, double minWidth,
    double height, Color color, String route) {
  return FlatButton(
    minWidth: minWidth,
    height: height,
    color: color,
    onPressed: () {
      Navigator.pushNamed(context, route);
    },
    shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
        side: BorderSide(color: color)),
    child: Text(
      text,
      style: new TextStyle(fontSize: 20, color: Colors.white),
    ),
  );
}
