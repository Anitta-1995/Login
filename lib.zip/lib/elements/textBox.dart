import 'package:flutter/material.dart';

class User extends StatelessWidget {
  const User({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: _buildText('username', Icon(Icons.person), false, 230.0),
    );
  }
} //UserNameBox

class Pswd extends StatelessWidget {
  const Pswd({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: _buildText('password', Icon(Icons.vpn_key), true, 230.0),
    );
  }
} //PasswordBox

class Number extends StatelessWidget {
  const Number({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: _buildText('Enter your Number', null, false, 180),
    );
  }
} //NumberBox

class OtpBox extends StatelessWidget {
  const OtpBox({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: _buildText('Enter OTP', null, false, 180),
    );
  }
} //OtpBox

Widget _buildText(String hintText, Icon icon, bool obscureText, double width) {
  var inputDecoration = InputDecoration(
    hintStyle: TextStyle(fontSize: 17),
    hintText: hintText,
    icon: icon,
    border: InputBorder.none,
  );
  return Container(
    padding: const EdgeInsets.all(8.0),
    alignment: Alignment.center,
    height: 55.0,
    width: width,
    decoration: new BoxDecoration(
        border: new Border.all(color: Colors.black26, width: 1.5),
        borderRadius: new BorderRadius.circular(12.0)),
    child: TextField(
      obscureText: obscureText,
      decoration: inputDecoration,
    ),
  );
}
