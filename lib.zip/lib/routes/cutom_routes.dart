import 'package:flutter/material.dart';
import '../views/home/login.dart';
import '../views/home/otp.dart';

var customRoutes = <String, WidgetBuilder>{
  '/': (context) => LogInPage(),
  '/otp': (context) => OtpPage(),
};
