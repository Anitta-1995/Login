import 'package:flutter/material.dart';
import '../../elements/textBox.dart';
import '../../elements/ui_button.dart';
import '../../elements/label.dart';

class LogInPage extends StatefulWidget {
  LogInPage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _LogInPageState createState() => _LogInPageState();
}

class _LogInPageState extends State<LogInPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 0, 250, 20),
              child: SignInLabel(),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 20, 0, 0),
              child: User(),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Pswd(),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 300, 0, 10),
              child: LogButton(),
            )
          ],
        ),
      ),
    );
  }
}
