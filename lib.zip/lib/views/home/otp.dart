import 'package:flutter/material.dart';
import '../../elements/textBox.dart';
import '../../elements/ui_button.dart';
import '../../elements/label.dart';

class OtpPage extends StatefulWidget {
  OtpPage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _OtpPageState createState() => _OtpPageState();
}

class _OtpPageState extends State<OtpPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 0, 250, 20),
              child: OtpLabel(),
            ),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(100, 20, 10, 0),
                  child: Number(),
                ), //Number
                Padding(
                  padding: const EdgeInsets.fromLTRB(0, 20, 0, 0),
                  child: SendButton(),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 10, 45, 0),
              child: OtpBox(),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 10, 50, 0),
              child: Text('( 2 min 32 sec remaining )'),
            ),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(40, 300, 40, 10),
                  child: NextButton(),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(100, 300, 40, 10),
                  child: Backbutton(),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
